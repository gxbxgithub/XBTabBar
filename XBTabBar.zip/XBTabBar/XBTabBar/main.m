//
//  main.m
//  XBTabBar
//
//  Created by guoxb on 15/10/15.
//  Copyright © 2015年 guoxb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
