//
//  XBTabBarButton.h
//  XBTabBarButton
//
//  Created by guoxb on 15/9/24.
//  Copyright (c) 2015年 guoxb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XBTabBarButton : UIButton
@property (nonatomic, strong) UITabBarItem *item;
@end
