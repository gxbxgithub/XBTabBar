//
//  XBTabBarController.h
//  XBTabBar
//
//  Created by guoxb on 15/10/15.
//  Copyright © 2015年 guoxb. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 ** ViewControllers
 **/
#import "XBViewController1.h"
#import "XBViewController2.h"
#import "XBViewController3.h"
#import "XBViewController4.h"

/**
 ** XBTabBar
 **/
#import "XBTabBar.h"

@interface XBTabBarController : UITabBarController

@end
