//
//  XBViewController4.m
//  XBTabBar
//
//  Created by guoxb on 15/10/15.
//  Copyright © 2015年 guoxb. All rights reserved.
//

#import "XBViewController4.h"

@interface XBViewController4 ()

@end

@implementation XBViewController4

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
}

@end
