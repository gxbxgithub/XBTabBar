//
//  XBViewController2.h
//  XBTabBar
//
//  Created by guoxb on 15/10/15.
//  Copyright © 2015年 guoxb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XBViewController2 : UIViewController

@end
