//
//  XBViewController1.h
//  XBTabBar
//
//  Created by guoxb on 15/10/15.
//  Copyright © 2015年 guoxb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XBViewController1 : UIViewController

@end
