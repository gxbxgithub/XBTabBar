//
//  XBViewController3.m
//  XBTabBar
//
//  Created by guoxb on 15/10/15.
//  Copyright © 2015年 guoxb. All rights reserved.
//

#import "XBViewController3.h"

@interface XBViewController3 ()

@end

@implementation XBViewController3

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor cyanColor];
}

@end
